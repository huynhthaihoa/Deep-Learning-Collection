rm -f assignment4.zip
zip -r assignment4.zip *.py ./chr_en_data ./sanity_check_en_es_data ./outputs